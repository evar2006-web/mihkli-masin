# Mihkli masin – masinaprofiil

| Väli | Väärtus / kontroll |
|---|---|
| Masina tootja ja mudel | VAJA KINNITADA |
| Juhtsüsteem | Heidenhain TNC 640 |
| Juhtsüsteemi NC tarkvara versioon | VAJA KINNITADA |
| Teljed / kinemaatika | VAJA KINNITADA |
| Lineaar- ja pöördtelgede piirid | VAJA KINNITADA |
| Tööriistavahetuse süntaks ja ohutud positsioonid | VAJA KINNITADA |
| Nullpunkti / preset-tabeli kasutus | VAJA KINNITADA |
| Spindli pöörlemine, jahutus, M-koodid | VAJA KINNITADA |
| Tsüklid ja saadaval olevad optsioonid | VAJA KINNITADA |
| Faili laiend, kodeering ja ülekandeviis | VAJA KINNITADA (TNCremo on varem mainitud) |
| Inkrementaalsed liikumised / kordusloogika | Täpne lubatud vorm VAJA KINNITADA |

## Eesmärgid
- Fusion 360 töötlusraja korrektne Heidenhaini dialoogi-NC väljund.
- Tarbetu korduva NC-teksti vähendamine vaid juhul, kui töötlemise geomeetria ja ohutus säilivad.
- Simulatsiooni- ja testitulemuste dokumenteerimine.

## Ohutuskontroll
- [ ] Kõik teljed ja liikumiste suunad kinnitatud
- [ ] Ohutud kiirliikumised ja retract tasandid kontrollitud
- [ ] Tööriistapikkuse kompensatsioon kontrollitud
- [ ] Puurimis- ja freesimistsüklid kontrollitud
- [ ] Üleskutsete ja alamprogrammide semantika kontrollitud
- [ ] Tööriista, tooriku ja kinnituse kokkupõrkekontroll
- [ ] Operaator kinnitas testprogrammi enne masina käivitamist
