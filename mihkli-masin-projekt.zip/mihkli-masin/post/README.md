# Postprotsessor

Lisa siia **algne** Fusion 360 `heidenhain.cps` fail. Hoia muutmata alusfail eraldi, näiteks `heidenhain-original.cps`, ja arenda kohandatud faili nimega `mihkli-tnc640.cps`.

Ära kasuta kohandatud faili tootmises enne kõigi funktsioonide valideerimist.
