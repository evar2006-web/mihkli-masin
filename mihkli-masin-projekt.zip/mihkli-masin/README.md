# Mihkli masin – Fusion 360 / Heidenhain TNC 640 postprotsessor

Privaatseks arenduseks mõeldud projekt Fusion 360 CAM-i postprotsessori kohandamiseks konkreetsele CNC-freespingile.

## Kinnitatud info
- Juhtsüsteem: **Heidenhain TNC 640** (kasutaja varasem info).
- CAM: **Autodesk Fusion 360**.
- Olemas on olnud Fusioni `heidenhain.cps` alusfail, kuid seda pole siia projekti veel lisatud.
- Eesmärk: kompaktsem, ohutu ja pingiga sobiv NC-väljund, sh korduvate töötlusradade/inkrementaalsete liikumiste võimaluste hindamine.

## Kontrollimist vajab
Pingi täpne tootja/mudel, telgede arv ja suunad, kinemaatika, tarkvaraoptsioonid, tööriistavahetus, nullpunktid, ohutu liikumise tasandid, tsüklid, M-funktsioonid ja juhttarkvara versioon. Neid **ei tohi ära arvata**.

## Järgmised sammud
1. Lisa Fusion 360-st eksporditud `heidenhain.cps` faili koopia kausta `post/`.
2. Täida `docs/machine-profile.md` tegeliku pingi seadistusega.
3. Lisa anonüümseks tehtud pingis töötav näidisprogramm kausta `examples/`.
4. Muuda postprotsessorit eraldi arendusharus; testi võrdlusnäidetega.
5. Kontrolli NC-väljundit tootja dokumentatsiooni, masina simulatsiooni ja operaatori kontrolli abil enne tegelikku töötlust.

**OHUTUS:** selles repos pole valmis ega valideeritud tootmispostprotsessorit. Ükski loodud programm ei ole automaatselt pingis käivitamiseks sobiv. Testi ohutu kõrguse, üksikplokk-režiimi ja kuivkäiguga vastavalt pingi ohutusjuhistele.
