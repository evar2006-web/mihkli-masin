# Testid

Soovitatavad võrdlustööd: 2D kontuur, tasku, puurimine, tööriistavahetus, mitu Z-taset, nullpunktivahetus, katkestamine/taaskäivitamine. Salvesta NC-väljund ja kontrolli erinevused enne päris pingi kasutamist.
